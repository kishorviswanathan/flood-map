var DATASET_ID = 'cjkwig8wk0wom31o7hym3tv5n';
var DATASETS_BASE = 'https://api.mapbox.com/datasets/v1/kishorv06/' + DATASET_ID + '/';
var DATASETS_ACCESS_TOKEN = 'sk.eyJ1Ijoia2lzaG9ydjA2IiwiYSI6ImNqa3dpaTQxNjBkcm0zd213YXIxMnJjM3QifQ.Hh_Ed-RMVXuQ8GL1ub_3lQ';
var PUBLIC_ACCESS_TOKEN = 'pk.eyJ1Ijoia2lzaG9ydjA2IiwiYSI6ImNqa3dpYzR2djB6YmEzdnFuNXlzcnloMDEifQ.bpeBUY001h2018QHS30QzQ';
var STYLESHEET = 'mapbox://styles/kishorv06/cjkwidat21qo02ruj4t2fcmxy';
var LOAD_INFO_LAYERS = ['chennai-relief-camps', 'chennai-relief-camps-22nov'];
